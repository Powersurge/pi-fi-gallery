#!/bin/bash
ipaddress="$(ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $1}')";

# Make sure pi is up to date.
sudo apt-get update

# Install all dependencies.
sudo apt-get -y install apache2 php5

# Set permissions.
sudo chmod a+x /home/pi/pi-fi.sh
sudo chmod a+x /usr/local/bin/eyefiserver
sudo chmod 777 /etc/eyefiserver.conf
sudo chmod 777 /var/log/eyefiserver.log
sudo chown -R www-data:www-data /var/www/html

#Almost done!
echo
echo The remainder of your Raspberry Pi settings can now be configured with your web browser pointed at http://$ipaddress.  Please configure your pi now.
echo
read -p "Press [Enter] key to continue..."
echo
sudo /home/pi/pi-fi.sh
config="$(cat /var/www/html/config)";
url=${config%,*};

# Start the eye-fi server.
sudo systemd-tmpfiles --create
sudo systemctl enable eyefi
sudo systemctl start eyefi

# All done!
echo
echo Congratulations! Your Raspberry Pi is now ready to receive pictures from your camera\'s Eye-Fi card and upload them to $url.
