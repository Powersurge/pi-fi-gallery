<?php
// this starts the session
@session_start() or die("Unable to start session.");
  // *** Restrict Access To Page: Grant or deny access to this page
  $MM_authFailedURL="login.php";
  $MM_grantAccess=false;
  if ( isset($_SESSION['password']) or !file_exists("config") ) {
    $MM_grantAccess=true;
  }
  if (!$MM_grantAccess) {
    $MM_qsChar="?";
    if (stristr($MM_authFailedURL,"?")==true) { $MM_qsChar = "&"; }
    $MM_referrer = $_SERVER['REQUEST_URI'];
    if ($_GET!="") { $$MM_referrer = $MM_referrer."?".$_GET; }
    $MM_authFailedURL = $MM_authFailedURL.$MM_qsChar."accessdenied=".urlencode($MM_referrer);
    header("Location: ".$MM_authFailedURL);
    exit();
  }
?>
<?php
if ($_POST['MM_update']!="") {
  $file = fopen("config", "w") or die("Unable to open file!");
  fwrite($file, $_POST['url'].",".base64_encode($_POST['password']));
  fclose($file);
}
?>
<?php
$file = file_get_contents('config', true);
$config = explode(",", $file);
?>
<SCRIPT LANGUAGE="JavaScript">
function valid(form)
{
  form.submit.disabled=true;

  if (!form.url.value) {
    alert("GALLERY URL is required.");
    form.url.focus();
    form.url.select();
    form.submit.disabled=false;
    return false;
  }

  if (form.password.value.length<6) {
    alert("PASSWORD must be at least 6 characters.");
    form.password.focus();
    form.password.select();
    form.submit.disabled=false;
    return false;
  }

  if (form.password.value!=form.password1.value) {
    alert("PASSWORDS don't match.");
    form.password.focus();
    form.password.select();
    form.submit.disabled=false;
    return false;
  }
return true;
}
</script>
<form onSubmit="return valid(this)" name="form1" method="post" action="index.php">
<table border="0">
  <tr>
    <td>Uploader ID:</td><td><?php echo str_replace(":","",shell_exec('cat /sys/class/net/eth0/address')); ?></td>

  </tr>
  <tr>
    <td>Gallery URL:</td><td><input type="text" name="url" value="<?php echo $config[0]; ?>" size="50"></td>

  </tr>
  <tr>
    <td>Pi Admin Password:</td><td><input type="password" name="password" value="<?php echo base64_decode($config[1]); ?>" size="50"></td>
  </tr>
  <tr>
    <td>Confirm Password:</td><td><input type="password" name="password1" value="<?php echo base64_decode($config[1]); ?>" size="50"></td>
  </tr>
</table>
<input type="submit" name="submit" value="Save">
<input type="hidden" name="MM_update" value="true">
</form>

