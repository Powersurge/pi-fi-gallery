#!/bin/bash
mac="$(cat /sys/class/net/eth0/address)";
config="$(cat /var/www/html/config)";
url=${config%,*};
for file in /home/pi/Pictures/*/; do
  uploader=$(basename $file);
done
for file in /home/pi/Pictures/$uploader/*/; do
  user=$(basename $file);
done
while [ "$(ls -A /home/pi/Pictures/$uploader/$user)" ]; do
  for file in /home/pi/Pictures/$uploader/$user/*; do
    curl -X POST -F "uploader=$uploader" -F "user=$user" -F "image=@$file" $url/upload.php;
    rm  $file;
  done
done
rm -Rf /home/pi/Pictures/$uploader
content=$(curl -L $url/users.txt)
echo [EyeFiServer] > /etc/eyefiserver.conf
echo host_name: >> /etc/eyefiserver.conf
echo host_port: 59278 >> /etc/eyefiserver.conf
while read user; do
  IFS=',' read -r -a usr <<< "$user"
  echo [${usr[1]}] >> /etc/eyefiserver.conf
  echo upload_key=${usr[2]} >> /etc/eyefiserver.conf
  echo upload_dir=/home/pi/Pictures/${mac//:}/${usr[0]} >> /etc/eyefiserver.conf
  echo complete_execute=/home/pi/pi-fi.sh >> /etc/eyefiserver.conf
done <<< "$content"
echo geotag_enable:1 >> /etc/eyefiserver.conf
echo geotag_lag:3600 >> /etc/eyefiserver.conf
echo geotag_accuracy:140000 >> /etc/eyefiserver.conf
echo upload_uid:1000 >> /etc/eyefiserver.conf
echo upload_gid:1000 >> /etc/eyefiserver.conf
echo upload_file_mode:420 >> /etc/eyefiserver.conf
echo upload_dir_mode:509 >> /etc/eyefiserver.conf
sudo systemctl restart eyefi
