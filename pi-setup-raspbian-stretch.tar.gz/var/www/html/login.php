<?php
// this starts the session
@session_start() or die("Unable to start session.");
$file = file_get_contents('config', true);
$config = explode(",", $file);
// *** Validate request to log in to this site.
if ($_POST['password']!="") {
  $MM_redirectLoginSuccess="index.php";
  $MM_redirectLoginFailed="login.php?accessdenied=".urlencode($_GET['accessdenied']);
  if ($_POST['password']==base64_decode($config[1])) {
    // username and password match - this is a valid user
    $_SESSION['password']=$_POST['password'];
    if ($_GET['accessdenied']!="") {
      $MM_redirectLoginSuccess = $_GET['accessdenied'];
    }
    header("Location: ".$MM_redirectLoginSuccess);
    exit();
  }
  header("Location: ".$MM_redirectLoginFailed);
  exit();
}
?>
<form name="login" method="post" action="login.php?accessdenied=<?php echo urlencode($_GET['accessdenied']); ?>">
  <input type="password" name="password" autofocus>
  <input type="submit" name="submit" value="Login">
</form>

